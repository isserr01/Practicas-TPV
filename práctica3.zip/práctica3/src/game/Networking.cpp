﻿// This file is part of the course TPV2@UCM - Samir Genaim

#include "Networking.h"

#include <cassert>

#include "../sdlutils/SDLUtils.h"
#include "Game.h"
#include "LittleWolf.h"
#include "Bullets.h"

Networking::Networking() :
		sock(nullptr), _client_Id(0), _master_Id(0) {
}

Networking::~Networking() {
	if (sock != nullptr)
		NET_DestroyStreamSocket(sock);
}

bool Networking::init(const char *host, Uint16 port) {
	bool success = false;

	Msg m0;
	MsgWithMasterId m1;

	// The address of the server we want to connect to
	NET_Address *addr = NET_ResolveHostname(host);
	if (NET_WaitUntilResolved(addr, 1000) != NET_SUCCESS) {
		NET_UnrefAddress(addr);
		return success;
	}

	// Connect to the server
	sock = NET_CreateClient(addr, port);
	if (NET_WaitUntilConnected(sock, 1000) != NET_SUCCESS) {
		NET_DestroyStreamSocket(sock);
		NET_UnrefAddress(addr);
		sock = nullptr;
		return success;
	}

	// we do not need the address anymore
	NET_UnrefAddress(addr);

	void *conn[1];
	conn[0] = sock;

	// - wait for the server to send acceptance message
	if (NET_WaitUntilInputAvailable(conn, 1, 1000) > 0) {
		SDLNetUtils::buff_t buf = SDLNetUtils::receive(sock);
		// forward it
		if (!buf.error) {
			if (buf.size > 0) {
				m0.deserialize(buf.data);

				if (m0.type == _CONN_REQUEST_ACCEPTED) {
					m1.deserialize(buf.data);
					_client_Id = m1.clientId;
					_master_Id = m1.masterId;
					success = true;
					std::cout << "Connected with id " << (int) _client_Id
							<< " (the current master is client "
							<< (int) _master_Id << ")" << std::endl;

				} else {
					std::cout << "Connection request has been rejected!"
							<< std::endl;
				}
			} else {
				std::cout << "Something went wrong ..." << std::endl;
			}
		} else {
			std::cout << "Something went wrong ..." << std::endl;
		}
	} else {
		std::cout << "Did not get reply on time ..." << std::endl;
	}

	return success;
}

void Networking::disconnect() {
	if (sock == nullptr)
		return;
	NET_DestroyStreamSocket(sock);
	sock = nullptr;
}

void Networking::update() {
	assert(sock != nullptr);

	Msg m0;
	MsgWithMasterId m1;
	PlayerStateMsg m2;
	ShootMsg m3;
	MsgWithClientId m4;
	PlayerInfoMsg m5;
	DeadMsg m6;

	while (true) {
		SDLNetUtils::buff_t buf = SDLNetUtils::receive(sock);

		// if the server close the connection
		if (buf.error) {
			std::cout
					<< "Something went wrong with the connection to the server!"
					<< std::endl;
			SDLNetUtils::print_SDLNet_error_and_exit(1);
		}

		// we get nothing
		if (buf.size == 0)
			break;

		// handle the message
		m0.deserialize(buf.data);
		switch (m0.type) {
		case _CLIENT_CONNECTED:
			m1.deserialize(buf.data);
			_master_Id = m1.masterId;
			handle_new_client(m1.clientId);
			break;

		case _CLIENT_DISCONNECTED:
			m1.deserialize(buf.data);
			_master_Id = m1.masterId;
			handle_disconnet(m1.clientId);
			break;

		case _PLAYER_STATE:
			m2.deserialize(buf.data);
			handle_player_state(m2);
			break;

		case _PLAYER_INFO:
			m5.deserialize(buf.data);
			handle_player_info(m5);
			break;

		case _SHOOT:
			m3.deserialize(buf.data);
			handle_shoot(m3);
			break;

		case _DEAD:
			m6.deserialize(buf.data);
			handle_dead(m6);
			break;

		case _RESTART:
			handle_restart();
			break;

		default:
			break;
		}
	}
}

void Networking::send_state(const Vector2D &pos, float w, float h, float rot) {
	PlayerStateMsg m;
	m.type = _PLAYER_STATE;
	m.clientId = _client_Id;
	m.x = pos.getX();
	m.y = pos.getY();
	m.w = w;
	m.h = h;
	m.rot = rot;
	SDLNetUtils::serialized_send(m, sock);
}

void Networking::send_my_info(const Vector2D &pos, float w, float h, float rot,
		Uint8 state) {
	PlayerInfoMsg m;
	m.type = _PLAYER_INFO;
	m.clientId = _client_Id;
	m.x = pos.getX();
	m.y = pos.getY();
	m.w = w;
	m.h = h;
	m.rot = rot;
	m.state = state;
	SDLNetUtils::serialized_send(m, sock);
}

void Networking::send_shoot(Vector2D p, Vector2D v, int width, int height,
		float r) {
	ShootMsg m;
	m.type = _SHOOT;
	m.clientId = _client_Id;
	m.x = p.getX();
	m.y = p.getY();
	m.vx = v.getX();
	m.vy = v.getY();
	m.w = width;
	m.h = height;
	m.rot = r;
	m.timestamp = sdlutils().virtualTimer().currTime();
	SDLNetUtils::serialized_send(m, sock);
}

void Networking::send_dead(Uint8 id, Uint8 shooter, Uint32 timestamp) {
	DeadMsg m;
	m.type = _DEAD;
	m.clientId = id;
	m.shooter = shooter;
	m.timestamp = timestamp;
	SDLNetUtils::serialized_send(m, sock);
}

void Networking::send_restart() {
	Msg m;
	m.type = _RESTART;
	SDLNetUtils::serialized_send(m, sock);
}

void Networking::handle_player_state(const PlayerStateMsg& m) {
	if (m.clientId == _client_Id) return;

	Game::Instance()->get_littlewolf().updatePlayerPosition(m.clientId, m.x, m.y, m.rot);
}

void Networking::handle_player_info(const PlayerInfoMsg& m) {
	if (m.clientId == _client_Id) return;
	Game::Instance()->get_littlewolf().updatePlayerRemote(
		m.clientId, m.x, m.y, m.rot, m.state, 100, 0, "Player"); 
}

void Networking::handle_dead(const DeadMsg& m) {
	// Usar onPlayerDied en lugar de killPlayer
	Game::Instance()->get_littlewolf().onPlayerDied(m.clientId, m.shooter);
	Game::Instance()->get_bullets().disable_bullet(m.shooter, m.timestamp);
}

void Networking::handle_restart() {
	Game::Instance()->get_littlewolf().startRestartSequence();
}

void Networking::handle_new_client(Uint8 id) {
	if (id != _client_Id) {
		// Enviar mi información al nuevo cliente
		LittleWolf::Point pos = Game::Instance()->get_littlewolf().getLocalPosition();
		float theta = Game::Instance()->get_littlewolf().getLocalTheta();
		send_my_info(Vector2D(pos.x, pos.y), 0, 0, theta, 1);
	}
}

void Networking::handle_disconnet(Uint8 id) {
	// Marcar como not used (opcional)
	Game::Instance()->get_littlewolf().removePlayer(id);
}

void Networking::handle_shoot(const ShootMsg &m) {
	Game::Instance()->get_bullets().shoot(Vector2D(m.x, m.y),
			Vector2D(m.vx, m.vy), m.w, m.h, m.rot, m.clientId, m.timestamp);

	LittleWolf::Point localPos = Game::Instance()->get_littlewolf().getLocalPosition();
	float dx = m.x - localPos.x;
	float dy = m.y - localPos.y;
	float distance = sqrt(dx * dx + dy * dy);
	float volume = std::max(0.0f, std::min(1.0f, 1.0f - distance / 20.0f));

	sdlutils().soundEffects().at("gunshot").play("se", volume);
}